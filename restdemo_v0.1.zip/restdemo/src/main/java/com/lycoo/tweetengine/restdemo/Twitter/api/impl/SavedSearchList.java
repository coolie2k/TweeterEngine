package com.lycoo.tweetengine.restdemo.Twitter.api.impl;

import org.springframework.social.twitter.api.SavedSearch;

import java.util.ArrayList;


@SuppressWarnings("serial")
class SavedSearchList extends ArrayList<SavedSearch> {
}
